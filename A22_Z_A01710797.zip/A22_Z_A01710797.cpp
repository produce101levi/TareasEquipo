#include <iostream>
#include <vector>
#include <string>
using namespace std;

// Función para calcular el arreglo Z
vector<int> calcularZ(const string& S) {
    int n = S.length();
    vector<int> Z(n, 0); // Inicializamos el arreglo Z con ceros
    int L = 0, R = 0; // Limites del segmento que coincide con el prefijo

    for (int i = 1; i < n; ++i) {
        if (i <= R) {
            Z[i] = min(R - i + 1, Z[i - L]);
        }
        while (i + Z[i] < n && S[Z[i]] == S[i + Z[i]]) {
            ++Z[i];
        }
        if (i + Z[i] - 1 > R) {
            L = i;
            R = i + Z[i] - 1;
        }
    }
    return Z;
}

int main() {
    string P = "abc"; // Patrón
    string T = "xabcab3abc"; // Texto
    string S = P + "$" + T; // Concatenamos patrón, separador y texto
    
    // Calculamos el arreglo Z
    vector<int> Z = calcularZ(S);

    // Mostramos el arreglo Z
    cout << "Arreglo Z: ";
    for (int i = 0; i < Z.size(); ++i) {
        cout << Z[i] << " ";
    }
    cout << endl;

    // Mostrar coincidencias del patrón en el texto
    cout << "Coincidencias en el texto (índices): ";
    int lenP = P.length();
    for (int i = lenP + 1; i < Z.size(); ++i) {
        if (Z[i] == lenP) {
            cout << (i - lenP - 1) << " "; // Mostrar la posición de la coincidencia en el texto
        }
    }
    cout << endl;

    return 0;
}

